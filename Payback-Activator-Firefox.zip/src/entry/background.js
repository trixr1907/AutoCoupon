chrome.runtime.onInstalled.addListener(()=>{console.log("SOTA Payback Activator installed")});
