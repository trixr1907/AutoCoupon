"use strict";(()=>{var y=Object.defineProperty;var A=(i,t,e)=>t in i?y(i,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):i[t]=e;var s=(i,t,e)=>A(i,typeof t!="symbol"?t+"":t,e);var m=`
  #autocoupon-widget {
    position: fixed;
    top: 100px;
    right: 20px;
    z-index: 2147483647 !important;
    font-family: 'Segoe UI', 'Roboto', sans-serif;
    color: white;
    width: 380px;
    pointer-events: auto;
    opacity: 0;
    transform: translateY(-20px);
    transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1);
  }

  #autocoupon-widget.visible {
    opacity: 1;
    transform: translateY(0);
  }

  .sota-card {
    background: #000000 !important;
    border: 3px solid #ffffff !important;
    border-radius: 16px;
    padding: 24px;
    box-shadow: 0 10px 50px rgba(0,0,0,0.9);
    pointer-events: auto;
    overflow: hidden;
    position: relative;
    min-width: 380px;
  }

  .sota-card::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle at center, rgba(56, 189, 248, 0.08) 0%, transparent 60%);
    pointer-events: none;
    z-index: 0;
  }

  .sota-header {
    display: flex;
    align-items: center;
    gap: 16px;
    margin-bottom: 20px;
    position: relative;
    z-index: 1;
  }

  .sota-icon {
    width: 48px;
    height: 48px;
    background: linear-gradient(135deg, #0ea5e9 0%, #3b82f6 100%);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    box-shadow: 0 4px 12px rgba(14, 165, 233, 0.3);
  }

  .sota-title-group {
    flex: 1;
  }

  .sota-title {
    font-weight: 700;
    font-size: 18px;
    color: #ffffff;
    margin-bottom: 4px;
    letter-spacing: -0.5px;
  }

  .sota-status {
    font-size: 14px;
    color: #ffffff;
    font-weight: 600;
  }

  .sota-progress-container {
    height: 8px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 4px;
    overflow: hidden;
    margin-bottom: 20px;
    position: relative;
    z-index: 1;
  }

  .sota-progress-bar {
    height: 100%;
    width: 0%;
    background: linear-gradient(90deg, #0ea5e9, #3b82f6);
    border-radius: 4px;
    transition: width 0.3s ease;
  }

  .sota-progress-bar.success {
    background: linear-gradient(90deg, #22c55e, #16a34a);
  }

  .sota-progress-bar.error {
    background: linear-gradient(90deg, #ef4444, #dc2626);
  }

  .sota-toggle-container {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    margin-bottom: 16px;
    gap: 12px;
    pointer-events: auto;
    background: rgba(255, 255, 255, 0.05);
    padding: 8px 12px;
    border-radius: 8px;
    position: relative;
    z-index: 10;
  }

  .sota-toggle-label {
    font-size: 14px;
    color: #ffffff;
    font-weight: 700;
  }

  .sota-toggle-label.active {
    color: #f59e0b;
    text-shadow: 0 0 8px rgba(245, 158, 11, 0.4);
  }

  .sota-toggle {
    position: relative;
    display: inline-block;
    width: 36px;
    height: 20px;
    pointer-events: auto;
  }

  .sota-toggle input {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    z-index: 20;
    cursor: pointer;
    margin: 0;
  }

  .sota-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(255, 255, 255, 0.15);
    transition: .4s;
    border-radius: 20px;
    border: 1px solid rgba(255, 255, 255, 0.3);
  }

  .sota-slider:before {
    position: absolute;
    content: "";
    height: 14px;
    width: 14px;
    left: 3px;
    bottom: 2px;
    background-color: #cbd5e1;
    transition: .4s;
    border-radius: 50%;
  }

  input:checked + .sota-slider {
    background-color: rgba(245, 158, 11, 0.2);
    border-color: rgba(245, 158, 11, 0.8);
  }

  input:checked + .sota-slider:before {
    transform: translateX(16px);
    background-color: #f59e0b;
    box-shadow: 0 0 8px #f59e0b;
  }

  .sota-btn {
    background: linear-gradient(135deg, #0ea5e9 0%, #3b82f6 100%);
    border: none;
    border-radius: 8px;
    padding: 10px 16px;
    color: white;
    font-weight: 600;
    font-size: 14px;
    cursor: pointer;
    width: 100%;
    margin-bottom: 16px;
    transition: all 0.2s ease;
    box-shadow: 0 4px 12px rgba(14, 165, 233, 0.3);
    font-family: inherit;
    display: none;
    pointer-events: auto;
    position: relative;
    z-index: 10;
  }

  .sota-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 6px 16px rgba(14, 165, 233, 0.4);
  }

  .sota-btn:active {
    transform: translateY(1px);
    box-shadow: 0 2px 8px rgba(14, 165, 233, 0.3);
  }

  .sota-btn.visible {
    display: block;
    animation: fadeIn 0.3s ease;
  }

  .sota-stats-grid {
    display: flex;
    justify-content: space-between;
    gap: 8px;
    margin-top: 16px;
    margin-bottom: 16px;
  }

  .sota-stat-item {
    background: rgba(255, 255, 255, 0.1);
    padding: 10px 6px;
    border-radius: 8px;
    text-align: center;
    flex: 1;
    border: 1px solid rgba(255,255,255,0.2);
  }

  .sota-stat-value {
    font-size: 18px;
    font-weight: 800;
    color: #ffffff;
    display: block;
  }

  .sota-stat-label {
    font-size: 10px;
    color: #ffffff;
    text-transform: uppercase;
    font-weight: 700;
    margin-top: 2px;
    display: block;
  }

  .sota-disclaimer {
    font-size: 10px;
    color: rgba(255, 255, 255, 0.5);
    text-align: center;
    line-height: 1.4;
  }

  /* Support-Bereich */
  .sota-support-section {
    display: none;
    background: linear-gradient(135deg, rgba(34, 197, 94, 0.1) 0%, rgba(14, 165, 233, 0.1) 100%);
    border: 1px solid rgba(34, 197, 94, 0.3);
    border-radius: 12px;
    padding: 16px;
    margin-bottom: 16px;
    text-align: center;
    animation: fadeIn 0.5s ease;
  }

  .sota-support-section.visible {
    display: block;
  }

  .sota-support-title {
    font-size: 16px;
    font-weight: 700;
    color: #ffffff;
    margin-bottom: 8px;
  }

  .sota-support-text {
    font-size: 13px;
    color: rgba(255, 255, 255, 0.8);
    margin-bottom: 12px;
  }

  .sota-support-buttons {
    display: flex;
    gap: 10px;
    justify-content: center;
  }

  .sota-support-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 10px 16px;
    border-radius: 8px;
    text-decoration: none;
    font-size: 13px;
    font-weight: 600;
    transition: all 0.2s ease;
  }

  .sota-support-btn.kofi {
    background: linear-gradient(135deg, #ff5e5b 0%, #ff3333 100%);
    color: white;
    box-shadow: 0 4px 12px rgba(255, 94, 91, 0.3);
  }

  .sota-support-btn.kofi:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(255, 94, 91, 0.4);
  }

  .sota-support-btn.website {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: #ffffff;
  }

  .sota-support-btn.website:hover {
    background: rgba(255, 255, 255, 0.15);
    border-color: rgba(255, 255, 255, 0.5);
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(-5px); }
    to { opacity: 1; transform: translateY(0); }
  }
`;function x(){return`
    <div class="sota-card">
      <div class="sota-header">
        <div class="sota-icon">\u{1F3AF}</div>
        <div class="sota-title-group">
          <div class="sota-title">AutoCoupon</div>
          <div class="sota-status">Initialisierung...</div>
        </div>
      </div>
      
      <div class="sota-toggle-container">
        <span class="sota-toggle-label" id="turbo-label">\u26A1 Turbo (Risiko)</span>
        <label class="sota-toggle">
          <input type="checkbox" id="turbo-mode-toggle">
          <span class="sota-slider"></span>
        </label>
      </div>

      <button id="start-btn" class="sota-btn">\u{1F680} Aktivierung Starten</button>

      <div class="sota-progress-container">
        <div class="sota-progress-bar"></div>
      </div>
      
      <div class="sota-stats-grid three-cols">
        <div class="sota-stat-item success">
          <div class="sota-stat-value" id="activated-count">0</div>
          <div class="sota-stat-label">Neu aktiviert</div>
        </div>
        <div class="sota-stat-item neutral">
          <div class="sota-stat-value" id="already-active-count">0</div>
          <div class="sota-stat-label">Bereits aktiv</div>
        </div>
        <div class="sota-stat-item warning">
          <div class="sota-stat-value" id="unavailable-count">0</div>
          <div class="sota-stat-label">Nicht verf\xFCgbar</div>
        </div>
      </div>

      <!-- Support-Bereich (wird nach Abschluss eingeblendet) -->
      <div class="sota-support-section" id="support-section">
        <div class="sota-support-title">\u{1F389} Hat dir AutoCoupon geholfen?</div>
        <div class="sota-support-text">Unterst\xFCtze die Entwicklung mit einem Kaffee!</div>
        <div class="sota-support-buttons">
          <a href="https://ko-fi.com/ivotech" target="_blank" class="sota-support-btn kofi">
            \u2615 Ko-fi
          </a>
          <a href="https://ivo-tech.com" target="_blank" class="sota-support-btn website">
            \u{1F310} Website
          </a>
        </div>
      </div>
      
      <div class="sota-disclaimer">
        Privates Assistenz-Tool. Nutzung auf eigene Verantwortung.<br>
        Nicht f\xFCr kommerzielle Zwecke.
      </div>
    </div>
  `}var l={TURBO:{DELAY_MS:30},NORMAL:{MIN_DELAY_MS:700,MAX_DELAY_MS:1500,POST_CLICK_MIN_MS:500,POST_CLICK_MAX_MS:1e3},INITIAL_WAIT_MS:500},n={COUPON_CENTER:"pb-coupon-center",COUPON:"pbc-coupon",CTA:"pbc-coupon-call-to-action",ACTIVATE_BUTTON:"button.coupon__activate-button",CHECKMARK:'.coupon__checkmark, .checkmark, [class*="check"], [class*="aktiv"]',GREEN_CHECK:'svg[fill="green"], .icon--check, .icon-check'},u={ALREADY_ACTIVE:["aktiviert","eingel\xF6st","einl\xF6sen","ist aktiviert","bereits aktiviert"],NOT_YET_AVAILABLE:["in k\xFCrze","in kurze","demn\xE4chst","bald verf\xFCgbar"],EXPIRED:["abgelaufen","nicht verf\xFCgbar","beendet","vorbei"],CAN_ACTIVATE:["aktivieren","jetzt"]},d={WIDGET_ID:"autocoupon-widget",STYLES_ID:"autocoupon-styles",SHOW_DELAY_MS:0,REMOVE_DELAY_MS:500},h={ENABLED:!0,PREFIX:"[AutoCoupon]"};var p=class{constructor(){s(this,"element");s(this,"progressBar");s(this,"statusElement");s(this,"activatedCountElement");s(this,"alreadyActiveCountElement");s(this,"unavailableCountElement");s(this,"turboToggle");s(this,"startBtn");this.element=this.createWidget(),this.progressBar=this.querySelector(".sota-progress-bar"),this.statusElement=this.querySelector(".sota-status"),this.activatedCountElement=this.querySelector("#activated-count"),this.alreadyActiveCountElement=this.querySelector("#already-active-count"),this.unavailableCountElement=this.querySelector("#unavailable-count"),this.turboToggle=this.querySelector("#turbo-mode-toggle"),this.startBtn=this.querySelector("#start-btn"),this.initTurboToggle()}querySelector(t){let e=this.element.querySelector(t);if(!e)throw new Error(`Element nicht gefunden: ${t}`);return e}createWidget(){let t=document.getElementById(d.WIDGET_ID);t&&t.remove(),this.injectStyles();let e=document.createElement("div");return e.id=d.WIDGET_ID,e.innerHTML=x(),document.body.appendChild(e),requestAnimationFrame(()=>{e.classList.add("visible")}),e}injectStyles(){if(document.getElementById(d.STYLES_ID))return;let t=document.createElement("style");t.id=d.STYLES_ID,t.textContent=m,document.head.appendChild(t)}initTurboToggle(){this.turboToggle.addEventListener("change",()=>{this.element.querySelector("#turbo-label")?.classList.toggle("active",this.turboToggle.checked)})}updateStatus(t){this.statusElement.textContent=t}updateProgress(t,e="normal"){let o=Math.max(0,Math.min(100,t));this.progressBar.style.width=`${o}%`,this.progressBar.classList.remove("error","success"),e!=="normal"&&this.progressBar.classList.add(e)}updateStats(t,e,o){this.activatedCountElement.textContent=String(t),this.alreadyActiveCountElement.textContent=String(e),this.unavailableCountElement.textContent=String(o)}getElement(){return this.element}remove(t=0){if(t>0){setTimeout(()=>this.remove(0),t);return}this.element.classList.remove("visible"),setTimeout(()=>{this.element.parentNode?.removeChild(this.element)},d.REMOVE_DELAY_MS)}isTurboMode(){return this.turboToggle.checked}waitForStart(){return new Promise(t=>{this.startBtn.classList.add("visible"),this.startBtn.onclick=()=>{this.startBtn.classList.remove("visible"),t()}})}showSupportSection(){let t=this.element.querySelector("#support-section");t&&t.classList.add("visible")}};var b=class{constructor(){s(this,"level",h.ENABLED?0:3);s(this,"prefix",h.PREFIX)}setLevel(t){this.level=t}debug(...t){this.level<=0&&console.log(this.prefix,...t)}info(...t){this.level<=1&&console.info(this.prefix,...t)}warn(...t){this.level<=2&&console.warn(this.prefix,...t)}error(...t){this.level<=3&&console.error(this.prefix,...t)}success(...t){this.level<=0&&console.log(this.prefix,"\u2713",...t)}fail(...t){this.level<=0&&console.log(this.prefix,"\u2717",...t)}},a=new b;var v=class{detectAndActivate(t){let e=t.shadowRoot;if(!e)return a.debug("Kein Shadow Root auf Coupon"),"unavailable";if(this.hasActiveIndicator(e))return a.debug("Gr\xFCnes H\xE4kchen gefunden - Coupon bereits aktiv"),"already-active";if(this.hasActiveClass(t))return a.debug("Coupon hat aktive Klasse"),"already-active";let o=this.findActivateButton(e);if(!o)return a.debug("Kein Aktivierungs-Button gefunden"),"unavailable";let r=o.innerText?.toLowerCase().trim()||"",c=(e.textContent||"").toLowerCase();return this.determineStatusAndClick(o,r,c)}hasActiveIndicator(t){let e=t.querySelector(n.CHECKMARK),o=t.querySelector(n.GREEN_CHECK);return!!(e||o)}hasActiveClass(t){let e=t.className||"";return e.includes("activated")||e.includes("aktiv")}findActivateButton(t){let e=t.querySelector(n.CTA);if(!e)return a.debug("Kein CTA-Element gefunden"),null;let o=e.shadowRoot;if(!o)return a.debug("Kein Shadow Root auf CTA"),null;let r=o.querySelector(n.ACTIVATE_BUTTON);return r||(r=o.querySelector("button")),r}determineStatusAndClick(t,e,o){return this.matchesAnyPattern(e,u.ALREADY_ACTIVE)||this.matchesAnyPattern(o,["ist aktiviert","bereits aktiviert"])?(a.debug("Coupon bereits aktiviert:",e),"already-active"):this.matchesAnyPattern(e,u.NOT_YET_AVAILABLE)||this.matchesAnyPattern(o,u.NOT_YET_AVAILABLE)?(a.debug("Coupon noch nicht verf\xFCgbar (In K\xFCrze):",e),"unavailable"):this.matchesAnyPattern(e,u.EXPIRED)?(a.debug("Coupon abgelaufen/nicht verf\xFCgbar:",e),"unavailable"):t.disabled||t.style.display==="none"||!t.offsetParent?(a.debug("Button deaktiviert oder versteckt"),"unavailable"):this.matchesAnyPattern(e,u.CAN_ACTIVATE)?(a.debug("Klicke Aktivierungs-Button:",e),t.click(),"activated"):(a.debug("Unbekannter Button-Status:",e,"| Volltext:",o.substring(0,100)),"unavailable")}matchesAnyPattern(t,e){return e.some(o=>t.includes(o))}};var g=class{constructor(){s(this,"overlay");s(this,"detector");s(this,"stats");s(this,"startTime");this.overlay=new p,this.detector=new v,this.stats={activated:0,alreadyActive:0,unavailable:0,total:0},this.startTime=Date.now()}async start(){try{a.info("\u{1F680} Starte Coupon-Aktivierung..."),this.overlay.updateStatus("Initialisiere..."),this.overlay.updateProgress(5);let t=await this.findCoupons();if(t.length===0){this.handleNoCouponsFound();return}this.stats.total=t.length,a.success(`${this.stats.total} Coupons gefunden`),this.overlay.updateStatus(`${this.stats.total} Coupons gefunden! Bereit?`),this.overlay.updateStats(0,0,0),this.overlay.updateProgress(20),await this.overlay.waitForStart(),this.overlay.updateStatus("Starte Aktivierung..."),await this.processCoupons(t),this.finish()}catch(t){this.handleError(t)}}async findCoupons(){this.overlay.updateStatus("Suche Coupon-Center...");let t=document.querySelector(n.COUPON_CENTER);if(!t)throw new Error("Coupon-Center nicht gefunden. Bist du auf payback.de/coupons?");a.success("pb-coupon-center gefunden");let e=t.shadowRoot;if(!e)throw new Error("Shadow DOM nicht zug\xE4nglich.");a.success("Shadow Root zug\xE4nglich"),this.overlay.updateStatus("Scanne Coupons..."),this.overlay.updateProgress(15),await this.wait(l.INITIAL_WAIT_MS);let o=e.querySelectorAll(n.COUPON);return Array.from(o)}async processCoupons(t){for(let e=0;e<t.length;e++){let o=t[e],r=20+e/t.length*80;this.overlay.updateProgress(r),this.overlay.updateStatus(`Pr\xFCfe ${e+1} von ${this.stats.total}...`),await this.applyDelay();try{let c=this.detector.detectAndActivate(o);this.updateStats(c,e),c==="activated"&&!this.overlay.isTurboMode()&&await this.waitHuman(l.NORMAL.POST_CLICK_MIN_MS,l.NORMAL.POST_CLICK_MAX_MS),this.overlay.updateStats(this.stats.activated,this.stats.alreadyActive,this.stats.unavailable)}catch(c){a.fail(`Coupon ${e+1}:`,c),this.stats.unavailable++}}}updateStats(t,e){switch(t){case"activated":this.stats.activated++,a.success(`Coupon ${e+1} aktiviert`);break;case"already-active":this.stats.alreadyActive++;break;case"unavailable":this.stats.unavailable++;break}}async applyDelay(){this.overlay.isTurboMode()?await this.wait(l.TURBO.DELAY_MS):await this.waitHuman(l.NORMAL.MIN_DELAY_MS,l.NORMAL.MAX_DELAY_MS)}finish(){let t=((Date.now()-this.startTime)/1e3).toFixed(1);this.stats.activated>0?(this.overlay.updateStatus(`\u2705 ${this.stats.activated} neu aktiviert! (${t}s)`),this.overlay.updateProgress(100,"success")):(this.overlay.updateStatus("Alle Coupons waren bereits aktiv"),this.overlay.updateProgress(100,"normal")),setTimeout(()=>{this.overlay.showSupportSection()},500),this.overlay.remove(15e3)}handleError(t){let e=t instanceof Error?t.message:"Unbekannter Fehler";a.error("Activator Error:",t),this.overlay.updateStatus("Fehler: "+e),this.overlay.updateProgress(100,"error"),this.overlay.remove(6e3)}handleNoCouponsFound(){this.overlay.updateStatus("Keine Coupons gefunden. Eingeloggt?"),this.overlay.updateProgress(100,"error"),this.overlay.remove(5e3)}wait(t){return new Promise(e=>setTimeout(e,t))}waitHuman(t,e){let o=Math.floor(Math.random()*(e-t+1)+t);return new Promise(r=>setTimeout(r,o))}};var f=!1;async function E(){if(f){console.log("[AutoCoupon] Aktivierung l\xE4uft bereits.");return}f=!0,console.log("[AutoCoupon] \u{1F680} AutoCoupon gestartet");try{await new g().start()}catch(i){console.error("[AutoCoupon] Aktivierungsfehler:",i)}finally{f=!1}}chrome.runtime.onMessage.addListener((i,t,e)=>(i.action==="START_ACTIVATION"&&(E(),e({status:"started"})),!0));console.log("[AutoCoupon] Content Script geladen");})();
